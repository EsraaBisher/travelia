<?php $__env->startSection('title', 'Manage Destinations - E-Travel'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold text-orange mb-0">Manage Destinations</h3>
        <a href="<?php echo e(route('admin.destinations.create')); ?>" class="btn btn-purple">
            <i class="fa-solid fa-plus me-1"></i> Add New Destination
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success border-0 shadow-sm mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4">#</th>
                            <th>Image</th>
                            <th>Title</th>
                            <th>Price</th>
                            <th class="text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="ps-4"><?php echo e($destination->id); ?></td>
                                <td>
                                    <?php if($destination->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $destination->image)); ?>" alt="<?php echo e($destination->title); ?>" class="rounded" width="50" height="50" style="object-fit: cover;">
                                    <?php else: ?>
                                        <div class="bg-light rounded d-flex align-items-center justify-content-center text-muted" style="width: 50px; height: 50px;">
                                            <i class="fa-solid fa-image"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td class="fw-bold text-purple"><?php echo e($destination->name); ?></td>
                                <td>$<?php echo e(number_format($destination->price, 2)); ?></td>
                                <td class="text-end pe-4">
                                    <a href="<?php echo e(route('admin.destinations.edit', $destination->id)); ?>" class="btn btn-sm btn-outline-purple me-1">
                                        <i class="fa-solid fa-pen-to-square"></i> Edit
                                    </a>
                                    <form action="<?php echo e(route('admin.destinations.destroy', $destination->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this destination?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fa-solid fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-muted">No destinations found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php if(method_exists($destinations, 'hasPages') && $destinations->hasPages()): ?>
            <div class="card-footer bg-white border-0 py-3">
                <?php echo e($destinations->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ziada\Downloads\Compressed\travelia\resources\views/admin/destinations/index.blade.php ENDPATH**/ ?>